package com.santacoder.pkgverifier;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.santacoder.package_verifier.Verifier;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Verifier.checkVerifier(MainActivity.this, BuildConfig.APPLICATION_ID, BuildConfig.APPLICATION_ID);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (Verifier.IS_VERIFIED){
                    Toast.makeText(MainActivity.this, "Trueeee", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "False", Toast.LENGTH_SHORT).show();
                }
            }
        }, 1000);
    }
}